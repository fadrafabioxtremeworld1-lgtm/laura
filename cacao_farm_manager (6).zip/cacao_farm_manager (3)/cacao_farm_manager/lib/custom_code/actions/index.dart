export '/custom_code/actions/analizar_plaga_offline.dart'
    show analizarPlagaOffline;
