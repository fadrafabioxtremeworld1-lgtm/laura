import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/flutter_flow/custom_functions.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String? obtenerSintomasPlaga(String? plagaDetectada) {
  String obtenerSintomasPlaga(String plagaDetectada) {
    switch (plagaDetectada) {
      case 'Monilia':
        return '• Manchas marrones irregulares con un característico polvillo blancuzco o cremoso.\n• Frutos deformados, endurecidos y livianos al peso.';
      case 'Fitoftora':
        return '• Pudrición marrón oscura de consistencia firme en mazorcas y frutos.\n• Lesiones alargadas en tallos con aspecto de mancha de aceite o exudados.';
      case 'anthracnose':
        return '• Manchas circulares pequeñas, hundidas y de color marrón oscuro o negro en hojas y frutos maduros.\n• Presencia de puntos naranjas o rosados (esporas) en el centro de la lesión con humedad.';
      case 'escoba_de_bruja':
        return '• Hipertrofia de brotes vegetativos formando ramilletes densos parecidos a una "escoba".\n• Muerte regresiva de ramas, flores secas y frutos deformados con textura acorchada.';
      default:
        return '• Follaje vigoroso, brillante y de coloración verde uniforme.\n• Frutos sin lesiones, manchas ni deformaciones visibles.';
    }
  }
}
