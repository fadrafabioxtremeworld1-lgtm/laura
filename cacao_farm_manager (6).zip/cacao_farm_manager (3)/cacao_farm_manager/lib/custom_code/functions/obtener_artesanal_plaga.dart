import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/flutter_flow/custom_functions.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String? obtenerArtesanalPlaga(String? plagaDetectada) {
  String obtenerArtesanalPlaga(String plagaDetectada) {
    switch (plagaDetectada) {
      case 'Monilia':
        return '1. Realizar podas de sanidad eliminando chupones y ramas enfermas cada 15 días.\n2. Recolectar frutos momificados y hacer una fosa de al menos 50 cm de profundidad para enterrarlos con cal viva.\n3. Aplicación de caldo bordelés al 1% en la zona afectada.';
      case 'Fitoftora':
        return '1. Construir zanjas de drenaje para evitar encharcamientos en época de lluvias.\n2. Aplicación de pasta bordelés (cobre y cal) directamente en chancros o heridas del tronco.\n3. Raleo de árboles vecinos para permitir la entrada de luz solar.';
      case 'anthracnose':
        return '1. Eliminar restos de cosecha infectados y hojas caídas del suelo.\n2. Riego controlado evitando mojar excesivamente el follaje y los frutos en maduración.';
      case 'escoba_de_bruja':
        return '1. Cortar las escobas y ramas enfermas haciendo el corte 30 a 40 cm por debajo de la zona afectada.\n2. Desinfectar las herramientas de poda con lejía o alcohol entre árbol y árbol.\n3. Quemar o enterrar inmediatamente los tejidos cortados.';
      default:
        return '1. Mantener un monitoreo semanal de campo.\n2. Fertilización orgánica oportuna con compost o humus de lombriz para fortalecer la inmunidad de la planta.';
    }
  }
}
