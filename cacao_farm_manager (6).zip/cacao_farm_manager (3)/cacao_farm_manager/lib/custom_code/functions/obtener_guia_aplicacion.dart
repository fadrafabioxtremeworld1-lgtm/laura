import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/flutter_flow/custom_functions.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String? obtenerGuiaAplicacion(
  double ph,
  String tipoSuelo,
  int paso,
) {
// 1. Muy Ácido / Ácido (pH < 6.0) -> Cal Agrícola
  if (ph < 6.0) {
    if (paso == 1) {
      if (tipoSuelo == 'Arenoso') {
        return 'Dividir la dosis de Cal Agrícola en 2 aplicaciones al año para evitar que la lluvia la lave.';
      } else if (tipoSuelo == 'Arcilloso') {
        return 'Esparcir la Cal Agrícola de forma homogénea sobre terreno seco antes de las lluvias.';
      }
      return 'Esparcir la Cal Agrícola de forma uniforme sobre toda la superficie del terreno.';
    } else if (paso == 2) {
      if (tipoSuelo == 'Arenoso') {
        return 'Mezclar suavemente en los primeros 5 a 10 cm con un rastrillado superficial.';
      } else if (tipoSuelo == 'Arcilloso') {
        return 'Incorporar a 15-20 cm de profundidad con azadón para romper la compactación.';
      }
      return 'Incorporar en los primeros 10 a 15 cm mediante labranza ligera.';
    } else if (paso == 3) {
      return 'Realizar un riego moderado e incorporar materia orgánica 15 días después de encalar.';
    }
    return 'Esparcir la Cal Agrícola de forma uniforme sobre el terreno.';
  }

  // 2. Óptimo Cacao (pH 6.0 - 6.8) -> Compost
  else if (ph <= 6.8) {
    if (paso == 1) {
      if (tipoSuelo == 'Arenoso') {
        return 'Aplicar Compost bien descompuesto en el plato de la planta para retener humedad.';
      } else if (tipoSuelo == 'Arcilloso') {
        return 'Distribuir el Compost en la zona de goteo evitando acumulaciones en el tronco.';
      }
      return 'Aplicar Compost o humus bien descompuesto en la zona de proyección de la copa.';
    } else if (paso == 2) {
      return 'Cubrir el compost con hojarasca seca (mulch) sin remover las raíces superficiales.';
    } else if (paso == 3) {
      return 'Mantener riegos periódicos para activar la microbiología del suelo y liberar nutrientes.';
    }
    return 'Aplicar Compost descompuesto en la zona de proyección de la copa.';
  }

  // 3. Neutro / Mod. Alcalino (pH 6.9 - 7.5) -> Materia Orgánica
  else if (ph <= 7.5) {
    if (paso == 1) {
      if (tipoSuelo == 'Arcilloso') {
        return 'Aplicar Materia Orgánica compostada con biofertilizantes para soltar la estructura del suelo.';
      }
      return 'Esparcir Materia Orgánica rica en ácidos húmicos alrededor de la planta.';
    } else if (paso == 2) {
      return 'Incorporar ligeramente en los primeros 10 cm para ayudar a regular el pH hacia la zona neutra.';
    } else if (paso == 3) {
      return 'Realizar riegos constantes pero sin encharcar para favorecer la humificación.';
    }
    return 'Esparcir Materia Orgánica rica en ácidos húmicos alrededor de la planta.';
  }

  // 4. Muy Alcalino (pH > 7.5) -> Yeso Agrícola
  else {
    if (paso == 1) {
      if (tipoSuelo == 'Arcilloso') {
        return 'Aplicar Yeso Agrícola en bandas sobre las hileras para desplazar el exceso de sales/sodio.';
      } else if (tipoSuelo == 'Arenoso') {
        return 'Aplicar Yeso Agrícola fraccionado en 2 partes junto con riego controlado.';
      }
      return 'Esparcir el Yeso Agrícola de manera uniforme en la zona del plato del cultivo.';
    } else if (paso == 2) {
      return 'Mezclar con los primeros 10 a 15 cm de suelo evadiendo el contacto directo con el tronco.';
    } else if (paso == 3) {
      return 'Aplicar un riego pesado de lavado para ayudar a desplazar las sales del perfil del suelo.';
    }
    return 'Esparcir el Yeso Agrícola de manera uniforme en la zona del cultivo.';
  }

  return 'Consulte con su técnico agrícola para recomendaciones específicas.';
}
