import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'ph_color_node_model.dart';
export 'ph_color_node_model.dart';

class PhColorNodeWidget extends StatefulWidget {
  const PhColorNodeWidget({
    super.key,
    Color? color,
    String? value,
    bool? active,
  })  : this.color = color ?? const Color(0xFFFF4D4D),
        this.value = value ?? '4',
        this.active = active ?? false;

  final Color color;
  final String value;
  final bool active;

  @override
  State<PhColorNodeWidget> createState() => _PhColorNodeWidgetState();
}

class _PhColorNodeWidgetState extends State<PhColorNodeWidget> {
  late PhColorNodeModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PhColorNodeModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 36.0,
          height: 36.0,
          decoration: BoxDecoration(
            color: valueOrDefault<Color>(
              widget!.color,
              Color(0xFFFF4D4D),
            ),
            borderRadius: BorderRadius.circular(9999.0),
            shape: BoxShape.rectangle,
            border: Border.all(
              color: valueOrDefault<Color>(
                valueOrDefault<bool>(
                  widget!.active,
                  false,
                )
                    ? FlutterFlowTheme.of(context).primary
                    : Colors.transparent,
                Colors.transparent,
              ),
              width: valueOrDefault<double>(
                valueOrDefault<bool>(
                  widget!.active,
                  false,
                )
                    ? 2.0
                    : 2.0,
                2.0,
              ),
            ),
          ),
          alignment: AlignmentDirectional(0.0, 0.0),
          child: Icon(
            Icons.check_rounded,
            color: FlutterFlowTheme.of(context).onPrimary,
            size: 16.0,
          ),
        ),
        Text(
          valueOrDefault<String>(
            widget!.value,
            '4',
          ),
          style: FlutterFlowTheme.of(context).labelSmall.override(
                font: GoogleFonts.plusJakartaSans(
                  fontWeight:
                      FlutterFlowTheme.of(context).labelSmall.fontWeight,
                  fontStyle: FlutterFlowTheme.of(context).labelSmall.fontStyle,
                ),
                color: FlutterFlowTheme.of(context).secondaryText,
                letterSpacing: 0.0,
                fontWeight: FlutterFlowTheme.of(context).labelSmall.fontWeight,
                fontStyle: FlutterFlowTheme.of(context).labelSmall.fontStyle,
                lineHeight: 1.2,
              ),
        ),
      ].divide(SizedBox(height: 4.0)),
    );
  }
}
