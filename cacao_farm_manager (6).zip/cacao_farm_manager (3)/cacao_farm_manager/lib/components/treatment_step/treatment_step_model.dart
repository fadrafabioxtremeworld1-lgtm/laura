import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'treatment_step_widget.dart' show TreatmentStepWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class TreatmentStepModel extends FlutterFlowModel<TreatmentStepWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
