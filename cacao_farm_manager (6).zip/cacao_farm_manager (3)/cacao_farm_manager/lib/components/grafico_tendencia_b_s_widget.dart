import '/flutter_flow/flutter_flow_charts.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'grafico_tendencia_b_s_model.dart';
export 'grafico_tendencia_b_s_model.dart';

class GraficoTendenciaBSWidget extends StatefulWidget {
  const GraficoTendenciaBSWidget({super.key});

  @override
  State<GraficoTendenciaBSWidget> createState() =>
      _GraficoTendenciaBSWidgetState();
}

class _GraficoTendenciaBSWidgetState extends State<GraficoTendenciaBSWidget> {
  late GraficoTendenciaBSModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GraficoTendenciaBSModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Padding(
      padding:
          EdgeInsets.all(FlutterFlowTheme.of(context).designToken.spacing.md),
      child: Container(
        width: MediaQuery.sizeOf(context).width * 1.0,
        height: 400.0,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20.0),
            topRight: Radius.circular(20.0),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Container(
              width: 370.0,
              height: 266.6,
              child: FlutterFlowLineChart(
                data: [
                  FFLineChartData(
                    xData: FFAppState().indicesEjeX,
                    yData:
                        FFAppState().historialSuelos.map((e) => e.ph).toList(),
                    settings: LineChartBarData(
                      color: FlutterFlowTheme.of(context).primary,
                      barWidth: 2.0,
                      isCurved: true,
                      belowBarData: BarAreaData(
                        show: true,
                        color: FlutterFlowTheme.of(context).accent1,
                      ),
                    ),
                  )
                ],
                chartStylingInfo: ChartStylingInfo(
                  backgroundColor:
                      FlutterFlowTheme.of(context).secondaryBackground,
                  showBorder: false,
                ),
                axisBounds: AxisBounds(
                  minY: 1.0,
                  maxY: 14.0,
                ),
                xLabels: FFAppState()
                    .historialSuelos
                    .map((e) => dateTimeFormat("Md", e.fecha))
                    .toList(),
                xAxisLabelInfo: AxisLabelInfo(
                  title: 'Fecha',
                  titleTextStyle: TextStyle(
                    fontSize: 14.0,
                  ),
                  showLabels: true,
                  labelTextStyle: TextStyle(
                    color: FlutterFlowTheme.of(context).primary,
                    fontSize: 12.0,
                  ),
                  labelInterval: 2.0,
                  reservedSize: 30.0,
                ),
                yAxisLabelInfo: AxisLabelInfo(
                  title: 'pH',
                  titleTextStyle: TextStyle(),
                  showLabels: true,
                  labelTextStyle: TextStyle(
                    color: FlutterFlowTheme.of(context).primary,
                    fontSize: 12.0,
                  ),
                  labelInterval: 2.0,
                  reservedSize: 40.0,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
