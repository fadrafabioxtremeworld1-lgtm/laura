import '/flutter_flow/flutter_flow_charts.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'grafico_tendencia_b_s_widget.dart' show GraficoTendenciaBSWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GraficoTendenciaBSModel
    extends FlutterFlowModel<GraficoTendenciaBSWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
