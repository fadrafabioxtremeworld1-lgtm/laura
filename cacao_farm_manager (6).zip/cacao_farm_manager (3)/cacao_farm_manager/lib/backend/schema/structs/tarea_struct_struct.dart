// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TareaStructStruct extends BaseStruct {
  TareaStructStruct({
    String? titulo,
    String? hora,
    String? faselunar,
  })  : _titulo = titulo,
        _hora = hora,
        _faselunar = faselunar;

  // "titulo" field.
  String? _titulo;
  String get titulo => _titulo ?? '';
  set titulo(String? val) => _titulo = val;

  bool hasTitulo() => _titulo != null;

  // "hora" field.
  String? _hora;
  String get hora => _hora ?? '';
  set hora(String? val) => _hora = val;

  bool hasHora() => _hora != null;

  // "faselunar" field.
  String? _faselunar;
  String get faselunar => _faselunar ?? '';
  set faselunar(String? val) => _faselunar = val;

  bool hasFaselunar() => _faselunar != null;

  static TareaStructStruct fromMap(Map<String, dynamic> data) =>
      TareaStructStruct(
        titulo: data['titulo'] as String?,
        hora: data['hora'] as String?,
        faselunar: data['faselunar'] as String?,
      );

  static TareaStructStruct? maybeFromMap(dynamic data) => data is Map
      ? TareaStructStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'titulo': _titulo,
        'hora': _hora,
        'faselunar': _faselunar,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'titulo': serializeParam(
          _titulo,
          ParamType.String,
        ),
        'hora': serializeParam(
          _hora,
          ParamType.String,
        ),
        'faselunar': serializeParam(
          _faselunar,
          ParamType.String,
        ),
      }.withoutNulls;

  static TareaStructStruct fromSerializableMap(Map<String, dynamic> data) =>
      TareaStructStruct(
        titulo: deserializeParam(
          data['titulo'],
          ParamType.String,
          false,
        ),
        hora: deserializeParam(
          data['hora'],
          ParamType.String,
          false,
        ),
        faselunar: deserializeParam(
          data['faselunar'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'TareaStructStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is TareaStructStruct &&
        titulo == other.titulo &&
        hora == other.hora &&
        faselunar == other.faselunar;
  }

  @override
  int get hashCode => const ListEquality().hash([titulo, hora, faselunar]);
}

TareaStructStruct createTareaStructStruct({
  String? titulo,
  String? hora,
  String? faselunar,
}) =>
    TareaStructStruct(
      titulo: titulo,
      hora: hora,
      faselunar: faselunar,
    );
