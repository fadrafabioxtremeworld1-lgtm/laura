import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'disease_yield_scanner_widget.dart' show DiseaseYieldScannerWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DiseaseYieldScannerModel
    extends FlutterFlowModel<DiseaseYieldScannerWidget> {
  ///  Local state fields for this page.

  String? fotoSeleccionada;

  bool mostrarResultados = false;

  FFUploadedFile? imagenCapturada;

  String plagaResultado = 'sana';

  String nombrePlaga = 'Escanea una plaga';

  ///  State fields for stateful widgets in this page.

  bool isDataUploading_uploadData0ua = false;
  FFUploadedFile uploadedLocalFile_uploadData0ua =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');

  // Stores action output result for [Custom Action - analizarPlagaOffline] action in IconButton widget.
  String? resultadoPlaga;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
