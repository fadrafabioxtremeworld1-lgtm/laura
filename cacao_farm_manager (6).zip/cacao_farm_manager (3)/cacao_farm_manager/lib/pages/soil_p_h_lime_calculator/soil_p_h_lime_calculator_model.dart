import '/backend/schema/structs/index.dart';
import '/components/mode_selector/mode_selector_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'soil_p_h_lime_calculator_widget.dart' show SoilPHLimeCalculatorWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SoilPHLimeCalculatorModel
    extends FlutterFlowModel<SoilPHLimeCalculatorWidget> {
  ///  Local state fields for this page.

  bool evaluado = false;

  String productoCalculado = '---';

  String dosisCalculada = '---';

  ///  State fields for stateful widgets in this page.

  // Model for ModeSelector.
  late ModeSelectorModel modeSelectorModel;
  // State field(s) for Slider widget.
  double? sliderValue;
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;

  @override
  void initState(BuildContext context) {
    modeSelectorModel = createModel(context, () => ModeSelectorModel());
  }

  @override
  void dispose() {
    modeSelectorModel.dispose();
  }
}
