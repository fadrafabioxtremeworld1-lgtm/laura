import '/backend/schema/structs/index.dart';
import '/components/grafico_tendencia_b_s_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'historial_page_widget.dart' show HistorialPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HistorialPageModel extends FlutterFlowModel<HistorialPageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
